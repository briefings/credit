import pandas as pd
import numpy as np
import collections


class Representations:

    def __init__(self):
        """
        Constructor
        """

    @staticmethod
    def attributes():

        InstancesAttributes = collections.namedtuple(
            typename='InstancesAttributes', field_names=['url', 'dtype', 'labels'])

        url = 'https://raw.githubusercontent.com/exhypotheses/risk/develop/warehouse/representations/data.csv'

        dtype = {'duration_months': np.int64, 'credit_amount': np.int64, 'i_rate_by_disp_inc': np.int64, 'curr_res_since':
            np.int64, 'age_years': np.int64, 'n_e_credits_this_bank': np.int64, 'n_dependants': np.int64,
                 'e_chq_acc_status_1': np.int64, 'e_chq_acc_status_2': np.int64,
                 'credit_history_1': np.int64, 'credit_history_2': np.int64,
                 'purpose_1': np.int64, 'purpose_2': np.int64,
                 'savings_acc_class_1': np.int64, 'savings_acc_class_2': np.int64,
                 'curr_emp_class_1': np.int64, 'curr_emp_class_2': np.int64,
                 'sex_and_status_1': np.int64, 'sex_and_status_2': np.int64,
                 'other_debtors_class_1': np.int64, 'other_debtors_class_2': np.int64,
                 'property_1': np.int64, 'property_2': np.int64,
                 'other_i_plans_1': np.int64, 'other_i_plans_2': np.int64,
                 'housing_1': np.int64, 'housing_2': np.int64,
                 'job_1': np.int64, 'job_2': np.int64,
                 'A192': np.uint8, 'A201': np.uint8, 'female': np.uint8,
                 'reasonable': np.uint8}

        labels = 'reasonable'

        return InstancesAttributes._make((url, dtype, labels))

    def data(self):

        attributes = self.attributes()

        try:
            data_ = pd.read_csv(filepath_or_buffer=attributes.url, header=0,
                                encoding='utf-8', dtype=attributes.dtype)
        except OSError as err:
            raise Exception(err.strerror) in err

        return data_
